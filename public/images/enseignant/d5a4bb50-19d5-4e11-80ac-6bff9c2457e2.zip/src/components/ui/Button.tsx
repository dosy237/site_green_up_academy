import React from 'react';
import { Loader2 } from 'lucide-react';
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  icon?: React.ReactNode;
}
export function Button({
  children,
  className = '',
  variant = 'primary',
  size = 'md',
  isLoading = false,
  icon,
  ...props
}: ButtonProps) {
  const baseStyles =
  'inline-flex items-center justify-center font-semibold transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-[0.98]';
  const variants = {
    primary:
    'bg-primary text-white hover:bg-primary-dark shadow-lg hover:shadow-xl hover:shadow-primary/20 focus:ring-primary rounded-full',
    secondary:
    'bg-accent text-white hover:bg-accent-dark shadow-lg hover:shadow-xl hover:shadow-accent/20 focus:ring-accent rounded-full',
    outline:
    'border-2 border-gray-200 dark:border-gray-700 text-light-text dark:text-dark-text hover:border-primary hover:text-primary focus:ring-primary rounded-full bg-transparent',
    ghost:
    'text-light-text dark:text-dark-text hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl'
  };
  const sizes = {
    sm: 'px-4 py-2 text-sm gap-1.5',
    md: 'px-6 py-3 text-base gap-2',
    lg: 'px-8 py-4 text-lg gap-2.5'
  };
  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={isLoading || props.disabled}
      {...props}>

      {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
      {!isLoading && icon && <span>{icon}</span>}
      {children}
    </button>);

}