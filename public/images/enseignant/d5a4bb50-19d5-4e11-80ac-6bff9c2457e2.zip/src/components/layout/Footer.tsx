import React from 'react';
import {
  Leaf,
  Mail,
  Phone,
  MapPin,
  ArrowRight,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Youtube } from
'lucide-react';
import { Button } from '../ui/Button';
export function Footer() {
  const currentYear = new Date().getFullYear();
  const footerLinks = {
    programs: [
    {
      name: 'Bachelor Performance Énergétique',
      href: '#'
    },
    {
      name: 'Master Cybersécurité & Green IT',
      href: '#'
    },
    {
      name: 'Master Management Durable',
      href: '#'
    },
    {
      name: 'Formation Continue',
      href: '#'
    }],

    school: [
    {
      name: 'À propos',
      href: '#'
    },
    {
      name: 'Gouvernance',
      href: '#'
    },
    {
      name: 'Recherche & Innovation',
      href: '#'
    },
    {
      name: 'Vie étudiante',
      href: '#'
    },
    {
      name: 'Actualités',
      href: '#'
    }],

    resources: [
    {
      name: 'Admissions',
      href: '#'
    },
    {
      name: 'Financement',
      href: '#'
    },
    {
      name: 'FAQ',
      href: '#'
    },
    {
      name: 'Contact',
      href: '#'
    }]

  };
  const socialLinks = [
  {
    icon: Facebook,
    href: '#',
    label: 'Facebook'
  },
  {
    icon: Twitter,
    href: '#',
    label: 'Twitter'
  },
  {
    icon: Linkedin,
    href: '#',
    label: 'LinkedIn'
  },
  {
    icon: Instagram,
    href: '#',
    label: 'Instagram'
  },
  {
    icon: Youtube,
    href: '#',
    label: 'YouTube'
  }];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Newsletter Section */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4">
                Restez informé de la{' '}
                <span className="text-gradient">transition</span>
              </h3>
              <p className="text-gray-400 text-lg">
                Recevez nos actualités, conseils carrière et invitations aux
                événements.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Votre adresse email"
                className="flex-1 px-6 py-4 rounded-full bg-gray-800 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:border-primary transition-colors" />

              <Button className="bg-gradient-to-r from-primary to-primary-light hover:from-primary-dark hover:to-primary text-white border-none whitespace-nowrap">
                S'abonner
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary p-2.5 rounded-xl">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold block leading-none">
                  Green Up
                </span>
                <span className="text-sm text-primary font-medium tracking-widest uppercase">
                  Academy
                </span>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              L'école de référence pour les métiers de la transition écologique
              et du numérique responsable.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social, index) =>
              <a
                key={index}
                href={social.href}
                aria-label={social.label}
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-primary hover:text-white transition-all duration-300">

                  <social.icon className="h-5 w-5" />
                </a>
              )}
            </div>
          </div>

          {/* Programs */}
          <div>
            <h4 className="font-bold text-lg mb-6">Formations</h4>
            <ul className="space-y-3">
              {footerLinks.programs.map((link, index) =>
              <li key={index}>
                  <a
                  href={link.href}
                  className="text-gray-400 hover:text-white transition-colors text-sm underline-animate">

                    {link.name}
                  </a>
                </li>
              )}
            </ul>
          </div>

          {/* School */}
          <div>
            <h4 className="font-bold text-lg mb-6">L'École</h4>
            <ul className="space-y-3">
              {footerLinks.school.map((link, index) =>
              <li key={index}>
                  <a
                  href={link.href}
                  className="text-gray-400 hover:text-white transition-colors text-sm underline-animate">

                    {link.name}
                  </a>
                </li>
              )}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-bold text-lg mb-6">Ressources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link, index) =>
              <li key={index}>
                  <a
                  href={link.href}
                  className="text-gray-400 hover:text-white transition-colors text-sm underline-animate">

                    {link.name}
                  </a>
                </li>
              )}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>
                  15 Rue de Rivoli
                  <br />
                  75001 Paris, France
                </span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Phone className="h-5 w-5 text-primary shrink-0" />
                <a
                  href="tel:+33123456789"
                  className="hover:text-white transition-colors">

                  +33 1 23 45 67 89
                </a>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <a
                  href="mailto:contact@greenup-academy.fr"
                  className="hover:text-white transition-colors">

                  contact@greenup-academy.fr
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
            <p>© {currentYear} Green Up Academy. Tous droits réservés.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">
                Mentions légales
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Politique de confidentialité
              </a>
              <a href="#" className="hover:text-white transition-colors">
                CGU
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>);

}