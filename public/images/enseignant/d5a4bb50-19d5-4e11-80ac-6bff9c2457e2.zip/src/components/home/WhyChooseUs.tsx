import React from 'react';
import {
  Zap,
  Users,
  MapPin,
  Briefcase,
  Award,
  Globe,
  ArrowUpRight } from
'lucide-react';
const features = [
{
  icon: Zap,
  title: 'Innovation Pédagogique',
  description:
  "Méthodes d'apprentissage actives, projets réels avec des entreprises partenaires, et technologies de pointe.",
  stat: '40+',
  statLabel: 'Projets/an'
},
{
  icon: Briefcase,
  title: '100% Alternance',
  description:
  'Immersion professionnelle totale. Vous êtes rémunéré pendant vos études et opérationnel dès la sortie.',
  stat: '0€',
  statLabel: 'Frais de scolarité'
},
{
  icon: Users,
  title: 'Experts de Terrain',
  description:
  'Nos intervenants sont des professionnels en activité, leaders dans leurs domaines respectifs.',
  stat: '85%',
  statLabel: 'Pros en activité'
},
{
  icon: MapPin,
  title: 'Campus Paris Centre',
  description:
  "Un lieu d'apprentissage moderne au cœur de Paris, à deux pas de Châtelet. Accessible et inspirant.",
  stat: '2000',
  statLabel: "m² d'espace"
},
{
  icon: Award,
  title: 'Diplômes Reconnus',
  description:
  "Titres RNCP de niveau 6 et 7, reconnus par l'État et les entreprises du secteur.",
  stat: '100%',
  statLabel: 'Certifiés RNCP'
},
{
  icon: Globe,
  title: 'Réseau International',
  description:
  'Partenariats avec des universités européennes et opportunités de mobilité internationale.',
  stat: '12',
  statLabel: 'Pays partenaires'
}];

export function WhyChooseUs() {
  return (
    <section className="py-32 bg-light-bg dark:bg-dark-bg relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-semibold mb-4">
            Pourquoi nous choisir
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-light-text dark:text-dark-text mb-6">
            Une école{' '}
            <span className="font-display italic text-gradient">
              différente
            </span>
          </h2>
          <p className="text-lg text-light-muted dark:text-dark-muted">
            Nous ne formons pas seulement des étudiants, nous façonnons les
            leaders de la transition écologique de demain.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) =>
          <div
            key={index}
            className="group relative bg-white dark:bg-dark-card rounded-3xl p-8 hover-lift border border-transparent hover:border-primary/20 transition-all duration-500">

              {/* Gradient background on hover */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              <div className="relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center text-primary mb-6 group-hover:scale-110 group-hover:bg-gradient-to-br group-hover:from-primary group-hover:to-primary-light group-hover:text-white transition-all duration-300">
                  <feature.icon className="h-7 w-7" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-light-text dark:text-dark-text mb-3 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-light-muted dark:text-dark-muted mb-6 leading-relaxed">
                  {feature.description}
                </p>

                {/* Stat */}
                <div className="flex items-end justify-between pt-4 border-t border-gray-100 dark:border-gray-800">
                  <div>
                    <p className="text-3xl font-bold text-gradient">
                      {feature.stat}
                    </p>
                    <p className="text-xs text-light-muted dark:text-dark-muted">
                      {feature.statLabel}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-light-muted dark:text-dark-muted group-hover:bg-primary group-hover:text-white transition-all duration-300">
                    <ArrowUpRight className="h-5 w-5" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}