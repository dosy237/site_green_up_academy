import React, { useState } from 'react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import {
  Check,
  Upload,
  ArrowRight,
  ArrowLeft,
  Calendar,
  FileText } from
'lucide-react';
export function AdmissionsPage() {
  const [step, setStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    window.scrollTo(0, 0);
  };
  const steps = [
  {
    number: 1,
    title: 'Infos Personnelles'
  },
  {
    number: 2,
    title: 'Parcours'
  },
  {
    number: 3,
    title: 'Choix'
  },
  {
    number: 4,
    title: 'Documents'
  }];

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      {/* Hero */}
      <div className="bg-primary text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-4">Admissions 2025</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Rejoignez la prochaine promotion de leaders de la transition
            écologique. Processus 100% en ligne.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {isSubmitted ?
        <Card className="text-center py-16 animate-fade-in-up">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Candidature Envoyée !
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
              Merci de votre intérêt pour Green Up Academy. Notre équipe
              d'admission examinera votre dossier et vous contactera sous 48h
              pour un entretien.
            </p>
            <Button onClick={() => window.location.reload()}>
              Retour à l'accueil
            </Button>
          </Card> :

        <>
            {/* Progress Bar */}
            <div className="mb-12">
              <div className="flex justify-between items-center relative">
                <div className="absolute left-0 right-0 top-1/2 h-1 bg-gray-200 dark:bg-gray-700 -z-10"></div>
                {steps.map((s) =>
              <div
                key={s.number}
                className="flex flex-col items-center bg-gray-50 dark:bg-dark-bg px-2">

                    <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= s.number ? 'bg-accent text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'}`}>

                      {s.number}
                    </div>
                    <span className="text-xs font-medium mt-2 text-gray-600 dark:text-gray-400 hidden sm:block">
                      {s.title}
                    </span>
                  </div>
              )}
              </div>
            </div>

            {/* Form */}
            <Card className="p-8 shadow-xl border-t-4 border-accent">
              <form onSubmit={handleSubmit}>
                {step === 1 &&
              <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                      Informations Personnelles
                    </h2>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Nom
                        </label>
                        <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none"
                      required />

                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Prénom
                        </label>
                        <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none"
                      required />

                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Email
                        </label>
                        <input
                      type="email"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none"
                      required />

                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Téléphone
                        </label>
                        <input
                      type="tel"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none"
                      required />

                      </div>
                    </div>
                  </div>
              }

                {step === 2 &&
              <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                      Parcours Académique
                    </h2>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Dernier diplôme obtenu
                        </label>
                        <select className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none">
                          <option>Baccalauréat</option>
                          <option>Bac +2 (BTS, DUT, L2)</option>
                          <option>Licence / Bachelor (Bac +3)</option>
                          <option>Master 1</option>
                          <option>Master 2</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Établissement
                        </label>
                        <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none" />

                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Année d'obtention
                          </label>
                          <input
                        type="number"
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none" />

                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Moyenne générale
                          </label>
                          <input
                        type="text"
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none" />

                        </div>
                      </div>
                    </div>
                  </div>
              }

                {step === 3 &&
              <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                      Choix de Formation
                    </h2>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Programme souhaité
                      </label>
                      <select className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none">
                        <option>Bachelor Performance Énergétique</option>
                        <option>Master Cybersécurité & Green IT</option>
                        <option>Master Performance Énergétique</option>
                        <option>Master Management Durable</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Pourquoi Green Up Academy ?
                      </label>
                      <textarea
                    rows={6}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-dark-bg focus:ring-2 focus:ring-accent outline-none"
                    placeholder="Décrivez votre motivation...">
                  </textarea>
                    </div>
                  </div>
              }

                {step === 4 &&
              <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                      Documents
                    </h2>
                    <div className="grid md:grid-cols-2 gap-6">
                      {[
                  'CV',
                  'Lettre de Motivation',
                  'Relevés de notes',
                  "Pièce d'identité"].
                  map((doc) =>
                  <div
                    key={doc}
                    className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 text-center hover:border-accent transition-colors cursor-pointer bg-gray-50 dark:bg-dark-bg">

                          <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                          <p className="font-medium text-gray-900 dark:text-white">
                            {doc}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            PDF, JPG (Max 5Mo)
                          </p>
                        </div>
                  )}
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <input
                    type="checkbox"
                    id="terms"
                    className="rounded text-accent focus:ring-accent"
                    required />

                      <label
                    htmlFor="terms"
                    className="text-sm text-gray-600 dark:text-gray-400">

                        Je certifie l'exactitude des informations fournies.
                      </label>
                    </div>
                  </div>
              }

                {/* Navigation Buttons */}
                <div className="flex justify-between mt-8 pt-8 border-t border-gray-100 dark:border-gray-800">
                  {step > 1 ?
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(step - 1)}
                  icon={<ArrowLeft className="h-4 w-4" />}>

                      Précédent
                    </Button> :

                <div></div>
                }

                  {step < 4 ?
                <Button
                  type="button"
                  onClick={() => setStep(step + 1)}
                  className="bg-accent hover:bg-accent-dark text-white border-none">

                      Suivant <ArrowRight className="h-4 w-4 ml-2" />
                    </Button> :

                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark text-white">

                      Envoyer ma candidature
                    </Button>
                }
                </div>
              </form>
            </Card>
          </>
        }
      </div>
    </div>);

}